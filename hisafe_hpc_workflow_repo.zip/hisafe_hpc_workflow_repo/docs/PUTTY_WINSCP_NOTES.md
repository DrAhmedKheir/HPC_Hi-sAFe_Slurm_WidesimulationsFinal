# PuTTY and WinSCP notes

## Reconnect after VPN disconnect

If VPN disconnects, PuTTY can freeze or show a network abort. Reconnect VPN, open PuTTY again, login, and check:

```bash
squeue -u kheir
```

SLURM jobs submitted with `sbatch` usually continue.

## Use tmux

```bash
tmux new -s hisafe
# detach: Ctrl+b then d
tmux attach -t hisafe
```

## WinSCP remote folder

```text
/mnt/home/kheir/simhisafer26/simhisafer26
```
