# Troubleshooting

## SticsV8 native library error

```bash
cd /mnt/home/kheir/simhisafer26/capsis4
mkdir -p linux-x86-64
ln -sf ../ext/linux64/libSticsV8.so linux-x86-64/libSticsV8.so
```

## Rscript not found

```bash
module avail 2>&1 | grep -i " r/"
module load r/4.4.1
which Rscript
```

## Missing R packages

```bash
mkdir -p ~/Rlibs
export R_LIBS_USER=~/Rlibs
module load r/4.4.1
Rscript scripts/advanced_hisafe_plots.R
```

The scripts install missing packages into `~/Rlibs`.

## X11 / PNG error

Use `options(bitmapType = "cairo")`, already included in the R scripts.

## `gap.degree is too large`

The chord script uses `gap.degree = 0.5`.

## `hclust size cannot exceed 65536`

The dendrogram script limits to the top 250 groups.
