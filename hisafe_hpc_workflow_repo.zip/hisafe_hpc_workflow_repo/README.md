# Hi-sAFe HPC Workflow

End-to-end workflow for preparing, running, monitoring, merging, and visualizing Hi-sAFe simulations on HPC using PuTTY, WinSCP, SLURM, and R.

## Main steps

```bash
# 1. Login with PuTTY, then go to project
cd /mnt/home/kheir/simhisafer26/simhisafer26

# 2. Prepare STICS native library once
bash scripts/02_prepare_stics_library.sh

# 3. Submit Hi-sAFe array
rm -f hisafer_*.out hisafer_*.err
sbatch --array=1-360%20 slurm/run_hisafe_array.slurm

# 4. Monitor
squeue -u kheir
watch -n 30 "squeue -u kheir"

# 5. Check outputs
bash scripts/04_check_outputs.sh

# 6. Load R
export R_LIBS_USER=~/Rlibs
module load r/4.4.1

# 7. Create advanced Hi-sAFe plots
Rscript scripts/advanced_hisafe_plots.R

# 8. Create Nature-style chord/Sankey/dendrogram plots
Rscript scripts/advanced_nature_plots.R
```

## Output folders

```text
advanced_plots_streaming/
nature_advanced_plots/
merged_outputs/
publication_plots/
```

Download these folders with WinSCP from:

```text
/mnt/home/kheir/simhisafer26/simhisafer26
```

## Notes

If PuTTY disconnects because VPN stops, SLURM jobs submitted with `sbatch` normally continue. Reconnect VPN, open PuTTY again, and run:

```bash
squeue -u kheir
```

Use `tmux` for long interactive sessions:

```bash
tmux new -s hisafe
# detach: Ctrl+b then d
tmux attach -t hisafe
```
