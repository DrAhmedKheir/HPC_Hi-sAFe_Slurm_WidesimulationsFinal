options(bitmapType = "cairo")

dir.create("~/Rlibs", showWarnings = FALSE, recursive = TRUE)
.libPaths(c("~/Rlibs", .libPaths()))

pkgs <- c("dplyr", "readr", "ggplot2", "stringr", "circlize", "igraph")
for (p in pkgs) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, lib = "~/Rlibs", repos = "https://cloud.r-project.org")
  }
}

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(stringr)
  library(circlize)
  library(igraph)
})

out_dir <- "nature_advanced_plots"
dir.create(out_dir, showWarnings = FALSE)
dir.create(file.path(out_dir, "chord"), showWarnings = FALSE)
dir.create(file.path(out_dir, "sankey"), showWarnings = FALSE)
dir.create(file.path(out_dir, "dendrogram"), showWarnings = FALSE)
dir.create(file.path(out_dir, "tables"), showWarnings = FALSE)

summary_file <- "advanced_plots_streaming/summary_tables/cell_distance_summary.csv"
if (!file.exists(summary_file)) stop("Missing summary file: ", summary_file)

d <- read_csv(summary_file, show_col_types = FALSE)

target_vars <- c(
  "yield", "lai", "cropTemperature", "soilSurfaceTemperature",
  "etpCalculated", "totalParIntercepted",
  "nitrogenLossNitrification", "totalCarbonHumusStock"
)
target_vars <- target_vars[target_vars %in% names(d)]

d <- d %>%
  filter(
    !is.na(cropSpeciesName),
    !tolower(cropSpeciesName) %in% c("baresoil", "bare soil", ""),
    !is.na(location),
    !is.na(orientation),
    !is.na(slope),
    !is.na(aspect),
    !is.na(x)
  ) %>%
  mutate(
    location = as.character(location),
    orientation = as.character(orientation),
    slope = as.character(slope),
    aspect = as.character(aspect),
    cropSpeciesName = as.character(cropSpeciesName),
    x = as.numeric(x)
  )

cat("Rows loaded:", nrow(d), "\n")
cat("Variables used:", paste(target_vars, collapse = ", "), "\n")

write_csv(d, file.path(out_dir, "tables", "nature_plot_input_summary.csv"))

safe_png <- function(filename, width = 3200, height = 2600, res = 300) {
  png(filename, width = width, height = height, res = res)
}

make_chord <- function(var) {
  cat("Making chord:", var, "\n")

  tmp <- d %>%
    group_by(location, cropSpeciesName) %>%
    summarise(value = mean(.data[[var]], na.rm = TRUE), .groups = "drop") %>%
    filter(is.finite(value), value > 0)

  if (nrow(tmp) < 2) return(NULL)

  mat <- xtabs(value ~ location + cropSpeciesName, tmp)

  safe_png(file.path(out_dir, "chord", paste0(var, "_location_crop_chord.png")))
  circos.clear()
  circos.par(
    gap.degree = 0.5,
    start.degree = 90,
    track.margin = c(0.01, 0.01),
    cell.padding = c(0.01, 0.01, 0.01, 0.01)
  )
  chordDiagram(mat, transparency = 0.35, annotationTrack = "grid")
  title(paste(var, "- location to crop chord diagram"))
  circos.clear()
  dev.off()
}

make_sankey_style <- function(var) {
  cat("Making Sankey-style:", var, "\n")

  tmp <- d %>%
    group_by(location, slope, orientation, cropSpeciesName) %>%
    summarise(value = mean(.data[[var]], na.rm = TRUE), .groups = "drop") %>%
    filter(is.finite(value))

  if (nrow(tmp) < 2) return(NULL)

  p <- ggplot(tmp, aes(y = value)) +
    geom_col(aes(x = location, fill = cropSpeciesName), width = 0.55) +
    geom_col(aes(x = slope, fill = cropSpeciesName), width = 0.55, alpha = 0.8) +
    geom_col(aes(x = orientation, fill = cropSpeciesName), width = 0.55, alpha = 0.65) +
    facet_wrap(~ cropSpeciesName, scales = "free_y") +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position = "none") +
    labs(title = paste(var, "- flow-style summary"), x = "Factor", y = var)

  ggsave(file.path(out_dir, "sankey", paste0(var, "_sankey_style.png")),
         p, width = 16, height = 10, dpi = 300)
}

make_dendrogram <- function(var) {
  cat("Making dendrogram:", var, "\n")

  tmp <- d %>%
    group_by(location, slope, orientation, aspect, cropSpeciesName, x) %>%
    summarise(value = mean(.data[[var]], na.rm = TRUE), .groups = "drop") %>%
    filter(is.finite(value)) %>%
    mutate(group_name = paste(location, slope, orientation, aspect, cropSpeciesName, paste0("x", x), sep = "_")) %>%
    arrange(desc(abs(value))) %>%
    slice_head(n = 250)

  if (nrow(tmp) < 5) return(NULL)

  mat <- as.matrix(tmp$value)
  rownames(mat) <- make.unique(tmp$group_name)
  mat <- scale(mat)
  mat[!is.finite(mat)] <- 0

  hc <- hclust(dist(mat), method = "ward.D2")
  dend <- as.dendrogram(hc)

  safe_png(file.path(out_dir, "dendrogram", paste0(var, "_dendrogram_top250.png")),
           width = 3600, height = 2600, res = 300)
  par(mar = c(5, 4, 4, 2))
  plot(dend, type = "rectangle", main = paste(var, "- dendrogram, top 250 groups"), cex = 0.35)
  dev.off()
}

for (v in target_vars) {
  make_chord(v)
  make_sankey_style(v)
  make_dendrogram(v)
  gc()
}

cat("Nature-style advanced plots finished.\n")
cat("Outputs written to:", normalizePath(out_dir), "\n")
