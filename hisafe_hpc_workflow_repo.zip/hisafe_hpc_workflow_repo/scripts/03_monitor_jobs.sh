#!/bin/bash
set -euo pipefail
USER_NAME="${1:-kheir}"
watch -n 30 "squeue -u $USER_NAME"
