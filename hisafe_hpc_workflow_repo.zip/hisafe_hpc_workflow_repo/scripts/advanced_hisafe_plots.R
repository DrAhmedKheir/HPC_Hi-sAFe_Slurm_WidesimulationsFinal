options(bitmapType = "cairo")

dir.create("~/Rlibs", showWarnings = FALSE, recursive = TRUE)
.libPaths(c("~/Rlibs", .libPaths()))

pkgs <- c("dplyr", "readr", "ggplot2", "stringr", "purrr")
for (p in pkgs) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, lib = "~/Rlibs", repos = "https://cloud.r-project.org")
  }
}

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(stringr)
  library(purrr)
})

out_dir <- "advanced_plots_streaming"
dir.create(out_dir, showWarnings = FALSE)
dir.create(file.path(out_dir, "distance"), showWarnings = FALSE)
dir.create(file.path(out_dir, "crop_rotation"), showWarnings = FALSE)
dir.create(file.path(out_dir, "location"), showWarnings = FALSE)
dir.create(file.path(out_dir, "summary_tables"), showWarnings = FALSE)

target_vars <- c(
  "yield",
  "lai",
  "cropTemperature",
  "soilSurfaceTemperature",
  "etpCalculated",
  "totalParIntercepted",
  "nitrogenLossNitrification",
  "totalCarbonHumusStock"
)

# Hi-sAFe cell files in this workflow have no header.
# Positions used here came from the current exported cells structure.
col_map <- c(
  Year = 4,
  x = 11,
  cropSpeciesName = 13,
  yield = 26,
  lai = 31,
  cropTemperature = 126,
  soilSurfaceTemperature = 120,
  etpCalculated = 112,
  totalParIntercepted = 134,
  nitrogenLossNitrification = 135,
  totalCarbonHumusStock = 136
)

cell_files <- list.files("runs", pattern = "_cells\\.txt$", recursive = TRUE, full.names = TRUE)
cat("Found cell files:", length(cell_files), "\n")

read_one_summary <- function(f, i, n) {
  cat("Processing file", i, "of", n, ":", basename(f), "\n")
  max_col <- max(col_map)

  d_raw <- tryCatch(
    readr::read_table(
      f,
      col_names = FALSE,
      col_types = cols(.default = col_character()),
      progress = FALSE,
      quote = "",
      comment = "",
      na = c("", "NA", "NaN")
    ),
    error = function(e) {
      cat("ERROR reading file:", f, "\n")
      cat(conditionMessage(e), "\n")
      return(NULL)
    }
  )

  if (is.null(d_raw)) return(NULL)

  if (ncol(d_raw) < max_col) {
    cat("Skipping file because it has only", ncol(d_raw), "columns; need", max_col, "\n")
    return(NULL)
  }

  d <- d_raw[, col_map, drop = FALSE]
  names(d) <- names(col_map)

  location <- str_extract(f, "Babing|Drolshagen|Hassleeben|Holle|Kremmen|Osternienburger_Land|Sch_nwald|Schierling")
  orientation <- str_extract(f, "O0|O45|O90")
  slope <- str_extract(f, "S0|S2p5|S5")
  aspect <- str_extract(f, "A0|A45|A90|A135|A180")
  scenario <- str_extract(f, "finalformat_[0-9]{2,3}")

  d %>%
    mutate(
      Year = suppressWarnings(as.integer(as.numeric(Year))),
      x = suppressWarnings(as.numeric(x)),
      cropSpeciesName = as.character(cropSpeciesName),
      across(all_of(target_vars), ~ suppressWarnings(as.numeric(.x))),
      location = location,
      orientation = orientation,
      slope = slope,
      aspect = aspect,
      scenario = scenario
    ) %>%
    filter(
      !is.na(Year),
      !is.na(x),
      x >= 0,
      x <= 12,
      !is.na(cropSpeciesName),
      !tolower(cropSpeciesName) %in% c("baresoil", "bare soil", "")
    ) %>%
    mutate(x = as.integer(round(x))) %>%
    group_by(location, orientation, slope, aspect, scenario, Year, x, cropSpeciesName) %>%
    summarise(
      across(all_of(target_vars), ~ mean(.x, na.rm = TRUE)),
      n_cells = n(),
      .groups = "drop"
    )
}

summary_list <- vector("list", length(cell_files))
for (i in seq_along(cell_files)) {
  summary_list[[i]] <- read_one_summary(cell_files[i], i, length(cell_files))
  if (i %% 20 == 0) gc()
}

summary_data <- bind_rows(summary_list)
cat("Summary rows:", nrow(summary_data), "\n")
if (nrow(summary_data) == 0) stop("No valid summary rows found. Check col_map positions.")

write_csv(summary_data, file.path(out_dir, "summary_tables", "cell_distance_summary.csv"))

make_distance_plot <- function(var) {
  p <- ggplot(summary_data, aes(x = x, y = .data[[var]], color = cropSpeciesName)) +
    stat_summary(fun = mean, geom = "line", linewidth = 1) +
    stat_summary(fun = mean, geom = "point", size = 1.5) +
    facet_grid(slope + aspect ~ orientation) +
    theme_bw() +
    labs(title = paste(var, "by distance from tree strip"),
         x = "Distance from tree strip, x (m)", y = var, color = "Crop")

  ggsave(file.path(out_dir, "distance", paste0(var, "_distance_orientation_slope_aspect.png")),
         p, width = 16, height = 10, dpi = 300)
}

make_location_plot <- function(var) {
  p <- ggplot(summary_data, aes(x = location, y = .data[[var]], fill = cropSpeciesName)) +
    geom_boxplot(outlier.size = 0.4) +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    labs(title = paste(var, "by location and crop"), x = "Location", y = var, fill = "Crop")

  ggsave(file.path(out_dir, "location", paste0(var, "_location_crop_boxplot.png")),
         p, width = 14, height = 8, dpi = 300)
}

make_crop_plot <- function(var) {
  p <- ggplot(summary_data, aes(x = cropSpeciesName, y = .data[[var]], fill = slope)) +
    geom_boxplot(outlier.size = 0.4) +
    facet_wrap(~ orientation) +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
    labs(title = paste(var, "by crop, slope, and orientation"), x = "Crop", y = var, fill = "Slope")

  ggsave(file.path(out_dir, "crop_rotation", paste0(var, "_crop_slope_orientation.png")),
         p, width = 14, height = 8, dpi = 300)
}

walk(target_vars, make_distance_plot)
walk(target_vars, make_location_plot)
walk(target_vars, make_crop_plot)

cat("Advanced streaming plots finished.\n")
cat("Outputs written to:", normalizePath(out_dir), "\n")
