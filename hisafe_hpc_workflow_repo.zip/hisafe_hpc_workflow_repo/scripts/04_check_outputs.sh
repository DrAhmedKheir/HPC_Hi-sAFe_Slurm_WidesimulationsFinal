#!/bin/bash
set -euo pipefail

cd /mnt/home/kheir/simhisafer26/simhisafer26

echo "Simulation summaries:"
find runs -name "*simulation_summary.csv" | wc -l

echo "Cell outputs:"
find runs -name "*_cells.txt" | wc -l

echo "Weather files:"
find weather -name "*.wth" | wc -l

echo "Recent errors:"
grep -Ri "error\|failed\|stale file handle\|No requested profiles" hisafer_*.err 2>/dev/null | tail -100 || true
