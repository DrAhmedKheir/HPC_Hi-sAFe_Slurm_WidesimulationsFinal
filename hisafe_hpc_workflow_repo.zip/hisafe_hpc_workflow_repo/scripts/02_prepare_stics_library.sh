#!/bin/bash
set -euo pipefail

CAPSIS_DIR="/mnt/home/kheir/simhisafer26/capsis4"
cd "$CAPSIS_DIR"

find "$CAPSIS_DIR" -name "libSticsV8.so"

mkdir -p linux-x86-64
ln -sf ../ext/linux64/libSticsV8.so linux-x86-64/libSticsV8.so

ls -lh linux-x86-64/libSticsV8.so
