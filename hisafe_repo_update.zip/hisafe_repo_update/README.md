# HPC Hi-sAFe Slurm Widesimulations Final

End-to-end workflow for large-scale Hi-sAFe agroforestry simulations on HPC, including scenario generation, SLURM execution, post-processing, advanced visualization, and machine-learning upscaling.

## Repository contents

```text
scripts/
  train_hisafe_ml_cells_weather_STREAMING_FINAL.R   # Final memory-safe ML training workflow

docs/
  ML_workflow.md                                    # Full ML documentation
  HPC_end_to_end_workflow.md                        # General HPC workflow notes

outputs_example/
  README.md                                        # Expected output folders and files
```

## Main Hi-sAFe workflow

1. Prepare weather files in Hi-sAFe `.wth` format.
2. Generate scenario folders for combinations of location, orientation, slope, and aspect.
3. Submit Hi-sAFe runs to HPC using SLURM.
4. Collect cell-level outputs from `*_cells.txt` files.
5. Generate publication figures from cell outputs.
6. Train ML models using daily weather, crop, distance, and scenario predictors.
7. Use trained ML models for future spatial prediction over Germany.

## Machine-learning extension

The final ML workflow trains Random Forest models using Hi-sAFe cell outputs and daily weather files.

Predictors:

- Year
- Day of year
- distance from tree strip (`x`)
- distance class
- location
- crop species
- orientation
- slope
- aspect
- decoded numeric orientation, slope, and aspect
- scenario code
- daily weather predictors when available

Targets:

- `yield`
- `totalCarbonHumusStock`
- `nitrogenLossNitrification`

Important post-processing:

- Hi-sAFe daily yield values are often zero before harvest.
- The ML script replaces daily zero-yield records with the maximum seasonal yield within each crop-year-location-scenario-distance group.
- This avoids training the model on artificial daily zero-yield values.

## Run ML training on HPC

```bash
cd /mnt/home/kheir/simhisafer26/simhisafer26
export R_LIBS_USER=~/Rlibs
module load r/4.4.1

tmux new -s mlstream
Rscript scripts/train_hisafe_ml_cells_weather_STREAMING_FINAL.R
```

Detach from tmux without stopping training:

```bash
Ctrl + B
D
```

Reconnect later:

```bash
tmux attach -t mlstream
```

## ML output folder

The script writes outputs to:

```text
/mnt/home/kheir/simhisafer26/simhisafer26/ml_cells_weather_final
```

Main outputs:

```text
models/
metrics/
figures/
tables/
shap/
```

Expected trained models:

```text
ranger_yield.rds
ranger_totalCarbonHumusStock.rds
ranger_nitrogenLossNitrification.rds
```

## Citation and reuse

This repository is intended as a reproducible HPC workflow for Hi-sAFe agroforestry scenario simulation, visualization, and ML-based upscaling.
