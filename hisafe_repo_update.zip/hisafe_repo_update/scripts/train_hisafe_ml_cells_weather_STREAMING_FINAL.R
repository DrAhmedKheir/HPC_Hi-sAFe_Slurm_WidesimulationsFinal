################################################################################
# train_hisafe_ml_cells_weather_STREAMING_FINAL.R
#
# Memory-safe ML workflow for Hi-sAFe HPC cell outputs.
#
# Inputs:
#   - Hi-sAFe cell files: /mnt/home/hisafe/**/*_cells.txt
#   - Daily weather files: weather/RG_strictly_positive/*.wth
#
# Outputs:
#   - ml_cells_weather_final/models
#   - ml_cells_weather_final/metrics
#   - ml_cells_weather_final/figures
#   - ml_cells_weather_final/tables
#   - ml_cells_weather_final/shap
################################################################################

options(bitmapType = "cairo")

# ------------------------------------------------------------------------------
# Package setup
# ------------------------------------------------------------------------------

dir.create("~/Rlibs", showWarnings = FALSE, recursive = TRUE)
.libPaths(c("~/Rlibs", .libPaths()))

pkgs <- c(
  "data.table", "dplyr", "stringr", "ggplot2",
  "ranger", "Metrics", "fastshap", "tidyr", "readr"
)

for (p in pkgs) {
  if (!requireNamespace(p, quietly = TRUE)) {
    install.packages(p, lib = "~/Rlibs", repos = "https://cloud.r-project.org")
  }
}

suppressPackageStartupMessages({
  library(data.table)
  library(dplyr)
  library(stringr)
  library(ggplot2)
  library(ranger)
  library(Metrics)
  library(fastshap)
  library(tidyr)
  library(readr)
})

set.seed(123)

# ------------------------------------------------------------------------------
# Paths and settings
# ------------------------------------------------------------------------------

project_dir <- "/mnt/home/kheir/simhisafer26/simhisafer26"
runs_dir    <- "/mnt/home/hisafe"
weather_dir <- file.path(project_dir, "weather/RG_strictly_positive")
out_dir     <- file.path(project_dir, "ml_cells_weather_final")

for (d in c(
  out_dir,
  file.path(out_dir, "tables"),
  file.path(out_dir, "tables", "per_file_summaries"),
  file.path(out_dir, "models"),
  file.path(out_dir, "figures"),
  file.path(out_dir, "metrics"),
  file.path(out_dir, "shap")
)) {
  dir.create(d, showWarnings = FALSE, recursive = TRUE)
}

targets <- c("yield", "totalCarbonHumusStock", "nitrogenLossNitrification")

# Safe settings for headnode/HPC memory
max_train_rows <- 1000000
max_eval_rows  <- 200000
max_shap_rows  <- 500
num_trees_safe <- 300

# Hi-sAFe cell-file column positions. These are based on the final Hi-sAFe output
# format used in the project.
col_map <- c(
  Year = 6,
  DOY = 7,
  x = 11,
  cropSpeciesName = 13,
  totalCarbonHumusStock = 113,
  cropTemperature = 121,
  yield = 126,
  nitrogenLossNitrification = 135
)

needed_cols <- as.integer(col_map)

known_locations <- c(
  "Babing", "Drolshagen", "Hassleben", "Hassleeben", "Holle",
  "Kremmen", "Osternienburger_Land", "Sch_nwald", "Schierling"
)

standardize_location <- function(x) {
  x <- as.character(x)
  x[x == "Hassleeben"] <- "Hassleben"
  x
}

# ------------------------------------------------------------------------------
# Weather reader
# ------------------------------------------------------------------------------

cat("Reading weather files...\n")

weather_files <- list.files(weather_dir, pattern = "\\.wth$", full.names = TRUE)

read_weather_one <- function(f) {
  loc <- known_locations[str_detect(basename(f), known_locations)][1]
  loc <- standardize_location(loc)

  w <- tryCatch(
    fread(f, fill = TRUE, data.table = FALSE, showProgress = FALSE),
    error = function(e) NULL
  )

  if (is.null(w) || nrow(w) == 0 || is.na(loc)) return(NULL)

  names(w) <- make.names(names(w), unique = TRUE)
  low <- tolower(names(w))

  year_col <- names(w)[str_detect(low, "year|yyyy")][1]
  doy_col  <- names(w)[str_detect(low, "doy|julian|dayofyear")][1]

  if (is.na(year_col)) {
    year_col <- names(w)[sapply(w, function(z) {
      zz <- suppressWarnings(as.integer(z))
      mean(zz >= 1990 & zz <= 2035, na.rm = TRUE) > 0.4
    })][1]
  }

  if (is.na(year_col)) return(NULL)

  if (is.na(doy_col)) {
    w$DOY_auto <- ave(
      seq_len(nrow(w)),
      suppressWarnings(as.integer(w[[year_col]])),
      FUN = seq_along
    )
    doy_col <- "DOY_auto"
  }

  # Flexible weather-column detection. If standard names are unavailable, use
  # numeric columns other than Year/DOY to create generic weather summaries.
  temp_cols <- names(w)[str_detect(low, "temp|tair|tmean|tmin|tmax|temperature")]
  rain_cols <- names(w)[str_detect(low, "rain|prec|ppt|precip")]
  rad_cols  <- names(w)[str_detect(low, "rad|solar|rg|global|par")]

  numeric_cols <- names(w)[sapply(w, function(z) {
    zz <- suppressWarnings(as.numeric(z))
    sum(is.finite(zz)) > 100
  })]
  numeric_cols <- setdiff(numeric_cols, c(year_col, doy_col, "DOY_auto"))

  if (length(temp_cols) == 0 && length(numeric_cols) >= 1) temp_cols <- numeric_cols[1]
  if (length(rain_cols) == 0 && length(numeric_cols) >= 2) rain_cols <- numeric_cols[2]
  if (length(rad_cols)  == 0 && length(numeric_cols) >= 3) rad_cols  <- numeric_cols[3]

  data.frame(
    location = loc,
    Year = suppressWarnings(as.integer(w[[year_col]])),
    DOY = suppressWarnings(as.integer(w[[doy_col]])),
    weather_mean_temp =
      if (length(temp_cols) > 0) rowMeans(sapply(w[temp_cols], as.numeric), na.rm = TRUE) else NA_real_,
    weather_total_precip =
      if (length(rain_cols) > 0) rowSums(sapply(w[rain_cols], as.numeric), na.rm = TRUE) else NA_real_,
    weather_total_radiation =
      if (length(rad_cols) > 0) rowMeans(sapply(w[rad_cols], as.numeric), na.rm = TRUE) else NA_real_
  ) %>%
    filter(!is.na(Year), !is.na(DOY), Year >= 1990, Year <= 2035)
}

weather_daily <- bind_rows(lapply(weather_files, read_weather_one))

write_csv(weather_daily, file.path(out_dir, "tables", "daily_weather_used.csv"))
cat("Weather rows:", nrow(weather_daily), "\n")

# ------------------------------------------------------------------------------
# Find cell files
# ------------------------------------------------------------------------------

cat("Finding cells files under:", runs_dir, "\n")

cell_files <- list.files(
  path = runs_dir,
  pattern = "_cells\\.txt$",
  recursive = TRUE,
  full.names = TRUE
)

# Fallback for shared folders where R list.files occasionally returns zero in
# older tmux sessions.
if (length(cell_files) == 0) {
  cmd <- "find /mnt/home/hisafe -name '*_cells.txt' 2>/dev/null"
  cell_files <- tryCatch(system(cmd, intern = TRUE), error = function(e) character(0))
}

cell_files <- unique(cell_files[file.exists(cell_files)])

cat("Found cells files:", length(cell_files), "\n")
writeLines(cell_files, file.path(out_dir, "tables", "found_cells_files.txt"))

if (length(cell_files) == 0) {
  stop("No *_cells.txt files found under /mnt/home/hisafe. Check group access and start a NEW login/tmux session.")
}

# ------------------------------------------------------------------------------
# Streaming cell-file processing
# ------------------------------------------------------------------------------

summary_files_dir <- file.path(out_dir, "tables", "per_file_summaries")

read_and_summarise_one <- function(f, i, n) {
  out_file <- file.path(
    summary_files_dir,
    paste0(tools::file_path_sans_ext(basename(f)), "_summary.csv")
  )

  if (file.exists(out_file) && file.info(out_file)$size > 0) {
    cat("Already exists, skipping:", basename(out_file), "\n")
    return(out_file)
  }

  cat("Processing", i, "of", n, ":", basename(f), "\n")

  location <- known_locations[str_detect(f, known_locations)][1]
  location <- standardize_location(location)

  orientation <- str_extract(basename(f), "O0|O45|O90")
  slope <- str_extract(basename(f), "S2p5|S5|S0")
  aspect <- str_extract(basename(f), "A180|A135|A90|A45|A0")

  d <- tryCatch(
    fread(
      f,
      header = FALSE,
      fill = TRUE,
      select = needed_cols,
      data.table = TRUE,
      showProgress = FALSE
    ),
    error = function(e) {
      cat("ERROR reading:", f, "\n")
      cat(conditionMessage(e), "\n")
      return(NULL)
    }
  )

  if (is.null(d) || nrow(d) == 0) return(NULL)

  setnames(d, names(col_map))

  d[, Year := suppressWarnings(as.integer(Year))]
  d[, DOY := suppressWarnings(as.integer(DOY))]
  d[, x := suppressWarnings(as.integer(round(as.numeric(x))))]
  d[, cropSpeciesName := as.character(cropSpeciesName)]

  d[, yield := suppressWarnings(as.numeric(yield))]
  d[, totalCarbonHumusStock := suppressWarnings(as.numeric(totalCarbonHumusStock))]
  d[, nitrogenLossNitrification := suppressWarnings(as.numeric(nitrogenLossNitrification))]
  d[, cropTemperature := suppressWarnings(as.numeric(cropTemperature))]

  d <- d[
    !is.na(Year) &
      !is.na(DOY) &
      !is.na(x) &
      x >= 0 &
      x <= 12 &
      !is.na(cropSpeciesName) &
      cropSpeciesName != "" &
      cropSpeciesName != "baresoil" &
      cropSpeciesName != "bare soil"
  ]

  if (nrow(d) == 0) return(NULL)

  d[, location := location]
  d[, orientation := orientation]
  d[, slope := slope]
  d[, aspect := aspect]

  # Correct yield: replace daily zero/pre-harvest yield by seasonal maximum.
  d[, yield_fixed := max(yield, na.rm = TRUE),
    by = .(location, orientation, slope, aspect, Year, x, cropSpeciesName)]
  d[!is.finite(yield_fixed), yield_fixed := NA_real_]
  d[, yield := yield_fixed]
  d[, yield_fixed := NULL]

  s <- d[, .(
    yield = mean(yield, na.rm = TRUE),
    totalCarbonHumusStock = mean(totalCarbonHumusStock, na.rm = TRUE),
    nitrogenLossNitrification = mean(nitrogenLossNitrification, na.rm = TRUE),
    cropTemperature = mean(cropTemperature, na.rm = TRUE),
    n_cells = .N
  ),
  by = .(
    location, Year, DOY, x, cropSpeciesName,
    orientation, slope, aspect
  )]

  fwrite(s, out_file)

  rm(d, s)
  gc()

  out_file
}

summary_paths <- character()

for (i in seq_along(cell_files)) {
  p <- read_and_summarise_one(cell_files[i], i, length(cell_files))
  if (!is.null(p)) summary_paths <- c(summary_paths, p)
  if (i %% 10 == 0) gc()
}

summary_paths <- unique(summary_paths[file.exists(summary_paths)])
cat("Per-file summaries available:", length(summary_paths), "\n")

if (length(summary_paths) == 0) {
  stop("No per-file summaries were created. Check column positions in col_map.")
}

# ------------------------------------------------------------------------------
# Combine compact summaries
# ------------------------------------------------------------------------------

cat("Combining compact summaries...\n")

ml_data_file <- file.path(out_dir, "tables", "ml_daily_training_table_streaming.csv")

if (file.exists(ml_data_file) && file.info(ml_data_file)$size > 0) {
  cat("Using existing compact ML table:", ml_data_file, "\n")
  ml_data <- fread(ml_data_file)
} else {
  ml_data <- rbindlist(lapply(summary_paths, fread), fill = TRUE)

  ml_data[, location := standardize_location(location)]

  ml_data[, orientation_deg := fifelse(orientation == "O0", 0,
                                fifelse(orientation == "O45", 45,
                                fifelse(orientation == "O90", 90, NA_real_)))]

  ml_data[, slope_percent := fifelse(slope == "S0", 0,
                              fifelse(slope == "S2p5", 2.5,
                              fifelse(slope == "S5", 5, NA_real_)))]

  ml_data[, aspect_deg := fifelse(aspect == "A0", 0,
                           fifelse(aspect == "A45", 45,
                           fifelse(aspect == "A90", 90,
                           fifelse(aspect == "A135", 135,
                           fifelse(aspect == "A180", 180, NA_real_)))))]

  ml_data[, distance_class := fifelse(x <= 2, "near_0_2m",
                               fifelse(x <= 5, "close_3_5m",
                               fifelse(x <= 8, "middle_6_8m", "far_9_12m")))]

  ml_data[, scenario_code := paste(orientation, slope, aspect, sep = "_")]

  cat("Merging daily weather...\n")

  if (nrow(weather_daily) > 0) {
    ml_data <- merge(
      ml_data,
      as.data.table(weather_daily),
      by = c("location", "Year", "DOY"),
      all.x = TRUE
    )
  } else {
    ml_data[, weather_mean_temp := NA_real_]
    ml_data[, weather_total_precip := NA_real_]
    ml_data[, weather_total_radiation := NA_real_]
  }

  fwrite(ml_data, ml_data_file)
}

cat("Final compact ML rows:", nrow(ml_data), "\n")

# ------------------------------------------------------------------------------
# ML training
# ------------------------------------------------------------------------------

predictors <- c(
  "Year", "DOY", "x", "distance_class",
  "location", "cropSpeciesName",
  "orientation", "slope", "aspect",
  "orientation_deg", "slope_percent", "aspect_deg",
  "scenario_code",
  "weather_mean_temp", "weather_total_precip", "weather_total_radiation"
)

weather_predictors <- c(
  "weather_mean_temp", "weather_total_precip", "weather_total_radiation"
)

valid_weather_predictors <- weather_predictors[
  sapply(ml_data[, ..weather_predictors], function(z) sum(is.finite(z), na.rm = TRUE) > 100)
]

predictors <- c(setdiff(predictors, weather_predictors), valid_weather_predictors)

cat("Predictors used:\n")
print(predictors)

factor_cols <- c(
  "distance_class", "location", "cropSpeciesName",
  "orientation", "slope", "aspect", "scenario_code"
)

metric_fun <- function(obs, pred) {
  data.frame(
    n = length(obs),
    R2 = cor(obs, pred, use = "complete.obs")^2,
    RMSE = Metrics::rmse(obs, pred),
    MAE = Metrics::mae(obs, pred),
    Bias = mean(pred - obs, na.rm = TRUE),
    NRMSE_percent = Metrics::rmse(obs, pred) / mean(obs, na.rm = TRUE) * 100
  )
}

all_metrics <- list()

for (target in targets) {
  cat("\n============================================================\n")
  cat("Training SAFE model for:", target, "\n")
  cat("============================================================\n")

  model_file <- file.path(out_dir, "models", paste0("ranger_", target, ".rds"))

  dat <- as.data.frame(ml_data[, c(predictors, target), with = FALSE])
  names(dat)[names(dat) == target] <- "response"

  dat <- dat[is.finite(dat$response), ]
  dat <- na.omit(dat)

  cat("Rows available:", nrow(dat), "\n")

  if (nrow(dat) < 1000) {
    cat("Skipping", target, "because too few rows.\n")
    next
  }

  for (fc in factor_cols) {
    if (fc %in% names(dat)) dat[[fc]] <- as.factor(dat[[fc]])
  }

  set.seed(123)

  train_n <- min(max_train_rows, nrow(dat))
  train_idx <- sample(seq_len(nrow(dat)), train_n)
  train_dat <- dat[train_idx, ]

  eval_pool <- dat[-train_idx, ]
  if (nrow(eval_pool) < 1000) eval_pool <- dat

  eval_n <- min(max_eval_rows, nrow(eval_pool))
  eval_idx <- sample(seq_len(nrow(eval_pool)), eval_n)
  eval_dat <- eval_pool[eval_idx, ]

  cat("Rows used for training:", nrow(train_dat), "\n")
  cat("Rows used for evaluation:", nrow(eval_dat), "\n")

  form <- as.formula(paste("response ~", paste(predictors, collapse = " + ")))

  model <- ranger(
    formula = form,
    data = train_dat,
    num.trees = num_trees_safe,
    mtry = max(2, floor(sqrt(length(predictors)))),
    min.node.size = 5,
    importance = "impurity",
    respect.unordered.factors = "order",
    oob.error = FALSE,
    write.forest = TRUE,
    num.threads = max(1, parallel::detectCores() - 2),
    seed = 123,
    verbose = TRUE
  )

  cat("Saving model immediately...\n")
  saveRDS(model, model_file)
  cat("Model saved:", model_file, "\n")

  cat("Predicting evaluation sample...\n")
  pred <- predict(model, data = eval_dat)$predictions

  pred_df <- data.frame(
    observed = eval_dat$response,
    predicted = pred,
    residual = pred - eval_dat$response
  )

  fwrite(pred_df, file.path(out_dir, "tables", paste0("predictions_sample_", target, ".csv")))

  metrics <- metric_fun(pred_df$observed, pred_df$predicted)
  metrics$target <- target
  metrics$train_rows <- nrow(train_dat)
  metrics$eval_rows <- nrow(eval_dat)
  all_metrics[[target]] <- metrics

  write_csv(metrics, file.path(out_dir, "metrics", paste0("metrics_", target, ".csv")))

  imp <- data.frame(
    predictor = names(model$variable.importance),
    importance = as.numeric(model$variable.importance)
  ) %>% arrange(desc(importance))

  write_csv(imp, file.path(out_dir, "metrics", paste0("feature_importance_", target, ".csv")))

  p1 <- ggplot(pred_df, aes(observed, predicted)) +
    geom_point(alpha = 0.25, size = 0.6) +
    geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "red") +
    theme_bw(base_size = 14) +
    labs(
      title = paste("Hi-sAFe vs ML:", target),
      subtitle = paste0(
        "R2 = ", round(metrics$R2, 3),
        " | RMSE = ", round(metrics$RMSE, 3),
        " | MAE = ", round(metrics$MAE, 3)
      ),
      x = "Hi-sAFe simulated",
      y = "ML predicted"
    )

  ggsave(file.path(out_dir, "figures", paste0("hisafe_vs_ml_", target, ".png")),
         p1, width = 7, height = 6, dpi = 400)

  p2 <- ggplot(pred_df, aes(predicted, residual)) +
    geom_point(alpha = 0.25, size = 0.6) +
    geom_hline(yintercept = 0, linetype = "dashed") +
    theme_bw(base_size = 14) +
    labs(title = paste("Residuals:", target), x = "Predicted", y = "Residual")

  ggsave(file.path(out_dir, "figures", paste0("residuals_", target, ".png")),
         p2, width = 7, height = 6, dpi = 400)

  p_imp <- ggplot(imp, aes(reorder(predictor, importance), importance)) +
    geom_col() +
    coord_flip() +
    theme_bw(base_size = 14) +
    labs(title = paste("Feature importance:", target), x = "Predictor", y = "Impurity importance")

  ggsave(file.path(out_dir, "figures", paste0("feature_importance_", target, ".png")),
         p_imp, width = 8, height = 6, dpi = 400)

  cat("Computing lightweight SHAP:", target, "\n")

  shap_sample <- train_dat[sample(seq_len(nrow(train_dat)), min(max_shap_rows, nrow(train_dat))), ]
  x_shap <- shap_sample[, predictors, drop = FALSE]

  pred_wrapper <- function(object, newdata) {
    predict(object, data = newdata)$predictions
  }

  shap_values <- tryCatch(
    fastshap::explain(
      object = model,
      X = x_shap,
      pred_wrapper = pred_wrapper,
      nsim = 10,
      adjust = FALSE
    ),
    error = function(e) {
      cat("SHAP failed for", target, ":", conditionMessage(e), "\n")
      NULL
    }
  )

  if (!is.null(shap_values)) {
    shap_imp <- as.data.frame(shap_values) %>%
      pivot_longer(everything(), names_to = "feature", values_to = "shap") %>%
      group_by(feature) %>%
      summarise(mean_abs_shap = mean(abs(shap), na.rm = TRUE), .groups = "drop") %>%
      arrange(desc(mean_abs_shap))

    write_csv(shap_imp, file.path(out_dir, "shap", paste0("shap_importance_", target, ".csv")))

    p_shap <- ggplot(shap_imp, aes(reorder(feature, mean_abs_shap), mean_abs_shap)) +
      geom_col() +
      coord_flip() +
      theme_bw(base_size = 14) +
      labs(title = paste("SHAP importance:", target), x = "Predictor", y = "Mean |SHAP|")

    ggsave(file.path(out_dir, "figures", paste0("shap_importance_", target, ".png")),
           p_shap, width = 8, height = 6, dpi = 400)
  }

  rm(dat, train_dat, eval_pool, eval_dat, pred, pred_df, model)
  gc()
}

all_metrics_df <- bind_rows(all_metrics)
write_csv(all_metrics_df, file.path(out_dir, "metrics", "all_metrics_summary.csv"))

if (nrow(all_metrics_df) > 0) {
  p_sum <- ggplot(all_metrics_df, aes(target, R2, fill = target)) +
    geom_col() +
    theme_bw(base_size = 14) +
    theme(legend.position = "none") +
    labs(title = "ML performance across Hi-sAFe targets", x = "Target variable", y = expression(R^2))

  ggsave(file.path(out_dir, "figures", "summary_R2_all_targets.png"),
         p_sum, width = 7, height = 5, dpi = 400)
}

cat("\nML SAFE streaming training finished successfully.\n")
cat("Outputs written to:", out_dir, "\n")
