# Expected outputs

This repository does not store large simulation outputs or trained models. They are generated on HPC.

## Hi-sAFe outputs

The raw cell-level outputs are expected under:

```text
/mnt/home/hisafe
```

The workflow searches recursively for:

```text
*_cells.txt
```

## ML outputs

The ML script writes outputs to:

```text
ml_cells_weather_final/
```

Expected contents:

```text
models/ranger_yield.rds
models/ranger_totalCarbonHumusStock.rds
models/ranger_nitrogenLossNitrification.rds
metrics/all_metrics_summary.csv
metrics/feature_importance_*.csv
figures/hisafe_vs_ml_*.png
figures/residuals_*.png
figures/feature_importance_*.png
shap/shap_importance_*.csv
tables/ml_daily_training_table_streaming.csv
tables/per_file_summaries/*.csv
```
