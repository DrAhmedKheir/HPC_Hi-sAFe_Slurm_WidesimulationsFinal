# Machine-learning workflow for Hi-sAFe HPC outputs

## Objective

Train machine-learning models from Hi-sAFe simulations using weather, crop, distance, and scenario predictors, then use the trained models for future upscaling to gridded Germany-wide weather datasets.

## Input data

### 1. Hi-sAFe cell output files

The script searches recursively in:

```bash
/mnt/home/hisafe
```

for files matching:

```text
*_cells.txt
```

### 2. Daily weather files

Daily weather files are expected under:

```bash
/mnt/home/kheir/simhisafer26/simhisafer26/weather/RG_strictly_positive
```

with `.wth` extension.

## Predictors

The ML predictors include:

- `Year`
- `DOY`
- `x`, distance from tree strip
- `distance_class`
- `location`
- `cropSpeciesName`
- `orientation`
- `slope`
- `aspect`
- `orientation_deg`
- `slope_percent`
- `aspect_deg`
- `scenario_code`
- daily weather variables, when available

## Target variables

The workflow trains separate Random Forest models for:

- `yield`
- `totalCarbonHumusStock`
- `nitrogenLossNitrification`

## Yield post-processing

Hi-sAFe daily yield is usually zero before harvest and becomes nonzero at harvest. To avoid training the ML model on artificial zero-yield values, the script replaces daily yield within each crop-year-scenario-distance group using the seasonal maximum yield.

Grouping used for yield correction:

```text
location + orientation + slope + aspect + Year + x + cropSpeciesName
```

## Memory-safe strategy

The full daily cell dataset can be very large. The script is designed to avoid memory failure by:

1. reading cell files one by one,
2. summarising each file to compact daily summaries,
3. saving per-file summaries to disk,
4. combining compact summaries only after streaming is complete,
5. training on a controlled random sample,
6. evaluating on a separate controlled sample,
7. saving each model immediately after training.

## Models

The workflow uses Random Forest regression through the R package `ranger`.

Important safety settings:

- `num.trees = 300`
- `max_train_rows = 1000000`
- `max_eval_rows = 200000`
- `oob.error = FALSE`
- model saved immediately after fitting

## Outputs

All outputs are written to:

```text
ml_cells_weather_final/
```

### Models

```text
models/ranger_yield.rds
models/ranger_totalCarbonHumusStock.rds
models/ranger_nitrogenLossNitrification.rds
```

### Metrics

```text
metrics/metrics_yield.csv
metrics/metrics_totalCarbonHumusStock.csv
metrics/metrics_nitrogenLossNitrification.csv
metrics/all_metrics_summary.csv
```

Metrics include:

- R²
- RMSE
- MAE
- Bias
- NRMSE (%)

### Feature importance

```text
metrics/feature_importance_*.csv
figures/feature_importance_*.png
```

### SHAP

```text
shap/shap_importance_*.csv
figures/shap_importance_*.png
```

### Prediction diagnostics

```text
figures/hisafe_vs_ml_*.png
figures/residuals_*.png
```

## Run command

```bash
cd /mnt/home/kheir/simhisafer26/simhisafer26
export R_LIBS_USER=~/Rlibs
module load r/4.4.1

tmux new -s mlstream
Rscript scripts/train_hisafe_ml_cells_weather_STREAMING_FINAL.R
```

## Monitoring

Check active processes:

```bash
top -u kheir
```

Check generated model files:

```bash
ls -lh ml_cells_weather_final/models
```

Check generated metrics:

```bash
ls -lh ml_cells_weather_final/metrics
```

Count generated files:

```bash
find ml_cells_weather_final -type f | wc -l
```
