# End-to-end Hi-sAFe HPC workflow

## 1. Project location

Working directory used on HPC:

```bash
/mnt/home/kheir/simhisafer26/simhisafer26
```

Shared simulation-output directory:

```bash
/mnt/home/hisafe
```

Weather directory:

```bash
/mnt/home/kheir/simhisafer26/simhisafer26/weather/RG_strictly_positive
```

## 2. Scenario design

The large-scale simulations combine:

- weather location
- crop rotation / crop species
- distance from tree strip
- orientation: `O0`, `O45`, `O90`
- slope: `S0`, `S2p5`, `S5`
- aspect: `A0`, `A45`, `A90`, `A135`, `A180`

Each scenario creates a separate Hi-sAFe run folder and corresponding output files.

## 3. Cell outputs

The main ML and visualization input is the Hi-sAFe cell output file:

```text
*_cells.txt
```

The workflow reads columns by fixed position because the raw file does not contain a conventional header row.

Important cell-output variables:

| Variable | Column position |
|---|---:|
| Year | 6 |
| DOY | 7 |
| x distance | 11 |
| cropSpeciesName | 13 |
| totalCarbonHumusStock | 113 |
| cropTemperature | 121 |
| yield | 126 |
| nitrogenLossNitrification | 135 |

## 4. Visualization workflow

Publication figures can be created from compact cell summaries. Useful visualization types include:

- distance-response plots
- location/crop boxplots
- crop × slope × orientation plots
- chord diagrams
- Sankey/alluvial diagrams
- circular dendrograms
- SEM-style conceptual diagrams

## 5. ML workflow

The ML workflow is documented in `docs/ML_workflow.md` and implemented in:

```text
scripts/train_hisafe_ml_cells_weather_STREAMING_FINAL.R
```

## 6. Storage checks

Check storage consumption:

```bash
du -sh /mnt/home/hisafe
du -sh /mnt/home/kheir/simhisafer26/simhisafer26/* | sort -h
```

Count cell output files:

```bash
find /mnt/home/hisafe -name "*_cells.txt" | wc -l
```

## 7. Recommended tmux use

Start a persistent session:

```bash
tmux new -s mlstream
```

Detach safely:

```text
Ctrl + B, then D
```

Reconnect:

```bash
tmux attach -t mlstream
```
